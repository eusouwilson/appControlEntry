"use strict";

/** @type {typeof import('@adonisjs/lucid/src/Lucid/Model')} */
const Model = use("Model");

class Campo extends Model {
  static get table() {
    return "v_matricula_campo";
  }
}

module.exports = Campo;
