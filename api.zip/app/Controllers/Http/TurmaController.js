"use strict";

/** @typedef {import('@adonisjs/framework/src/Request')} Request */
/** @typedef {import('@adonisjs/framework/src/Response')} Response */
/** @typedef {import('@adonisjs/framework/src/View')} View */
const Turma = use("App/Models/Turma");

/**
 * Resourceful controller for interacting with turmas
 */
class TurmaController {
  async index({ request, response, view }) {
    const turma = await Turma.all();

    return turma;
  }

  async show({ params, request, response, view }) {
    const turma = await Turma.query()
      .where("ano", "=", params.ano)
      .fetch();

    return turma;
  }
}

module.exports = TurmaController;
