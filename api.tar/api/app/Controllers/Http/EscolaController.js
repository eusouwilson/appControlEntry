"use strict";

/** @typedef {import('@adonisjs/framework/src/Request')} Request */
/** @typedef {import('@adonisjs/framework/src/Response')} Response */
/** @typedef {import('@adonisjs/framework/src/View')} View */
const Escola = use("App/Models/Escola");

/**
 * Resourceful controller for interacting with escolas
 */
class EscolaController {
  async index({ request, response, view }) {
    const escola = await Escola.all();

    return escola;
  }

  async show({ params, request, response, view }) {
    const escola = await Escola.query()
      .where("ano", "=", params.ano)
      .fetch();

    return escola;
  }
}

module.exports = EscolaController;
