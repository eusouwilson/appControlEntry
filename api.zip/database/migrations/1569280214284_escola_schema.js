'use strict'

/** @type {import('@adonisjs/lucid/src/Schema')} */
const Schema = use('Schema')

class EscolaSchema extends Schema {
  up () {
    this.create('escolas', (table) => {
      table.increments()
      table.timestamps()
    })
  }

  down () {
    this.drop('escolas')
  }
}

module.exports = EscolaSchema
