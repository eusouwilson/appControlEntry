"use strict";

/** @type {typeof import('@adonisjs/lucid/src/Lucid/Model')} */
const Model = use("Model");

class Serie extends Model {
  static get table() {
    return "V_serie_matriculas";
  }
}

module.exports = Serie;
