"use strict";

/** @typedef {import('@adonisjs/framework/src/Request')} Request */
/** @typedef {import('@adonisjs/framework/src/Response')} Response */
/** @typedef {import('@adonisjs/framework/src/View')} View */
const User = use("App/Models/User");

/**
 * Resourceful controller for interacting with users
 */
class UserController {
  async login({ auth, request, response }) {
    const { email, password } = request.all();

    try {
      let { cod_usuario, entidade, ativo, campo, e_mail } = await User.findBy(
        "password",
        password
      );

      if (e_mail !== email) {
        return { message: "E-mail ou senha incorretos!!! " };
      }
      const user = {
        cod_usuario,
        entidade,
        ativo,
        campo,
      };
      if (ativo === 1) {
        let accessToken = await auth.generate(user);
        return response.json({ user: user, access_token: accessToken });
      } else {
        return { message: "Usuario inativo" };
      }
    } catch (error) {
      return { message: "E-mail ou senha incorretos!!! " };
    }
  }
}

module.exports = UserController;
