"use strict";

/** @typedef {import('@adonisjs/framework/src/Request')} Request */
/** @typedef {import('@adonisjs/framework/src/Response')} Response */
/** @typedef {import('@adonisjs/framework/src/View')} View */
const Campo = use("App/Models/Campo");
/**
 * Resourceful controller for interacting with campos
 */
class CampoController {
  /**
   * Show a list of all campos.
   * GET campos
   *
   * @param {object} ctx
   * @param {Request} ctx.request
   * @param {Response} ctx.response
   * @param {View} ctx.view
   */
  async index({ request, response, view }) {
    const campo = await Campo.all();

    return campo;
  }

  /**
   * Display a single campo.
   * GET campos/:id
   *
   * @param {object} ctx
   * @param {Request} ctx.request
   * @param {Response} ctx.response
   * @param {View} ctx.view
   */
  async show({ params, request, response, view }) {
    const campo = await Campo.query()
      .where("ano", "=", params.ano)
      .fetch();

    return campo;
  }
}

module.exports = CampoController;
