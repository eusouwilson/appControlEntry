'use strict'

/** @type {import('@adonisjs/lucid/src/Schema')} */
const Schema = use('Schema')

class CampoSchema extends Schema {
  up () {
    this.create('campos', (table) => {
      table.increments()
      table.timestamps()
    })
  }

  down () {
    this.drop('campos')
  }
}

module.exports = CampoSchema
