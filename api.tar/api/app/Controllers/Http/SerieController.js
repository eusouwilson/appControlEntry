"use strict";

/** @typedef {import('@adonisjs/framework/src/Request')} Request */
/** @typedef {import('@adonisjs/framework/src/Response')} Response */
/** @typedef {import('@adonisjs/framework/src/View')} View */
const Serie = use("App/Models/Serie");

/**
 * Resourceful controller for interacting with series
 */
class SerieController {
  async index({ request, response, view }) {
    const serie = await Serie.all();

    return serie;
  }

  async show({ params, request, response, view }) {
    const serie = await Serie.query()
      .where("ano", "=", params.ano)
      .fetch();

    return serie;
  }
}

module.exports = SerieController;
