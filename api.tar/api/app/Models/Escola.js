"use strict";
const Model = use("Model");

class Escola extends Model {
  static get table() {
    return "v_matricula_escola";
  }
}

module.exports = Escola;
